import { useState, useEffect } from "react";
import { Navigation } from "@/components/Navigation";
import { CameraCapture } from "@/components/CameraCapture";
import { PokerAnalysis } from "@/components/PokerAnalysis";
import { DetectedCard } from "@/hooks/useCardDetection";
import { analyzeHand, PokerHand, HandAnalysis } from "@/lib/pokerCalculator";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Camera, Settings } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

/**
 * Página principal do PokerVision
 * Interface para análise de poker em tempo real
 */
export default function Home() {
  // Estados de câmera e detecção
  const [cameraActive, setCameraActive] = useState(true);
  const [detectedCards, setDetectedCards] = useState<DetectedCard[]>([]);

  // Estados de entrada manual
  const [holeCards, setHoleCards] = useState<string[]>(["As", "Kh"]);
  const [boardCards, setBoardCards] = useState<string[]>(["Qs", "Js", "Ts"]);

  // Estado de análise
  const [analysis, setAnalysis] = useState<HandAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Atualiza análise quando cartas mudam
  useEffect(() => {
    if (holeCards.length === 2 && boardCards.length > 0) {
      performAnalysis();
    }
  }, [holeCards, boardCards]);

  /**
   * Executa análise de poker
   */
  const performAnalysis = () => {
    setIsAnalyzing(true);
    try {
      const hand: PokerHand = {
        holeCards,
        boardCards,
      };
      const result = analyzeHand(hand);
      setAnalysis(result);
    } catch (error) {
      console.error("Erro na análise:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  /**
   * Callback quando cartas são detectadas pela câmera
   */
  const handleCardsDetected = (cards: DetectedCard[]) => {
    setDetectedCards(cards);
    // Atualiza hole cards com as 2 primeiras cartas detectadas
    if (cards.length >= 2) {
      const newHoleCards = [
        `${cards[0].rank}${getSuitCode(cards[0].suit)}`,
        `${cards[1].rank}${getSuitCode(cards[1].suit)}`,
      ];
      setHoleCards(newHoleCards);
    }
    // Atualiza board cards com as cartas restantes (até 5)
    if (cards.length > 2) {
      const newBoardCards = cards.slice(2, 7).map((card) => {
        return `${card.rank}${getSuitCode(card.suit)}`;
      });
      setBoardCards(newBoardCards);
    }
  };

  /**
   * Converte símbolo de naipe para código
   */
  const getSuitCode = (suit: string): string => {
    const suitMap: { [key: string]: string } = {
      "♠": "s",
      "♥": "h",
      "♦": "d",
      "♣": "c",
    };
    return suitMap[suit] || "s";
  };

  /**
   * Atualiza hole card individual
   */
  const updateHoleCard = (index: number, value: string) => {
    const newCards = [...holeCards];
    newCards[index] = value.toUpperCase();
    setHoleCards(newCards);
  };

  /**
   * Atualiza board card individual
   */
  const updateBoardCard = (index: number, value: string) => {
    const newCards = [...boardCards];
    newCards[index] = value.toUpperCase();
    setBoardCards(newCards);
  };

  /**
   * Adiciona uma carta ao board
   */
  const addBoardCard = () => {
    if (boardCards.length < 5) {
      setBoardCards([...boardCards, ""]);
    }
  };

  /**
   * Remove uma carta do board
   */
  const removeBoardCard = (index: number) => {
    setBoardCards(boardCards.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <Navigation />

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-12 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Análise de Poker</h1>
              <p className="text-sm text-gray-600">Estude e pratique com dados em tempo real</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCameraActive(!cameraActive)}
              className="gap-2"
            >
              <Camera className="w-4 h-4" />
              {cameraActive ? "Desativar" : "Ativar"} Câmera
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna Esquerda - Câmera e Entrada */}
          <div className="lg:col-span-2 space-y-6">
            {/* Câmera */}
            {cameraActive && (
              <Card>
                <CardHeader>
                  <CardTitle>Câmera</CardTitle>
                  <CardDescription>
                    Aponte para as cartas para detecção automática
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <CameraCapture onCardsDetected={handleCardsDetected} isActive={cameraActive} />
                </CardContent>
              </Card>
            )}

            {/* Entrada Manual */}
            <Card>
              <CardHeader>
                <CardTitle>Entrada Manual</CardTitle>
                <CardDescription>Digite as cartas manualmente (ex: As, Kh)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Hole Cards */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Suas Cartas (Hole Cards)
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {holeCards.map((card, idx) => (
                      <Input
                        key={idx}
                        value={card}
                        onChange={(e) => updateHoleCard(idx, e.target.value)}
                        placeholder={`Carta ${idx + 1}`}
                        maxLength={2}
                        className="font-mono text-center text-lg"
                      />
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Formato: Rank (A, K, Q, J, T, 9-2) + Naipe (s, h, d, c)
                  </p>
                </div>

                {/* Board Cards */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Cartas da Mesa (Board)
                    </label>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={addBoardCard}
                      disabled={boardCards.length >= 5}
                    >
                      + Adicionar
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {boardCards.map((card, idx) => (
                      <div key={idx} className="relative">
                        <Input
                          value={card}
                          onChange={(e) => updateBoardCard(idx, e.target.value)}
                          placeholder={`Carta ${idx + 1}`}
                          maxLength={2}
                          className="font-mono text-center text-lg"
                        />
                        {boardCards.length > 3 && (
                          <button
                            onClick={() => removeBoardCard(idx)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Flop (3), Turn (4) ou River (5) cartas
                  </p>
                </div>

                {/* Botão de Análise */}
                <Button
                  onClick={performAnalysis}
                  disabled={isAnalyzing}
                  className="w-full"
                  size="lg"
                >
                  {isAnalyzing ? "Analisando..." : "Analisar Mão"}
                </Button>
              </CardContent>
            </Card>

            {/* Info sobre Cartas Detectadas */}
            {detectedCards.length > 0 && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {detectedCards.length} carta(s) detectada(s) pela câmera. As cartas foram
                  preenchidas automaticamente.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Coluna Direita - Análise */}
          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-lg">Análise em Tempo Real</CardTitle>
                <CardDescription>Resultados e recomendações</CardDescription>
              </CardHeader>
            </Card>

            <PokerAnalysis analysis={analysis} isLoading={isAnalyzing} />

            {/* Info Box */}
            <Card className="bg-amber-50 border-amber-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-amber-900">
                  💡 Dica de Uso
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-amber-800">
                  Este app é para estudo e prática. Use em ambiente controlado para treinar
                  análise de poker. Não use em cassinos ou jogos reais.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
